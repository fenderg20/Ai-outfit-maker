import { useState } from "react";
import { motion } from "framer-motion";

export default function OutfitMaker() {
  const [style, setStyle] = useState("");
  const [fabric, setFabric] = useState("");
  const [color, setColor] = useState("");
  const [neckline, setNeckline] = useState("");
  const [sleeves, setSleeves] = useState("");
  const [generatedPrompt, setGeneratedPrompt] = useState("");

  const handleGenerate = () => {
    const prompt = `A ${color} ${fabric} ${style} dress with ${neckline} neckline and ${sleeves} sleeves, high fashion editorial lighting, full body.`;
    setGeneratedPrompt(prompt);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6 flex flex-col items-center">
      <h1 className="text-3xl font-bold mb-6">AI Outfit Maker ✨</h1>

      <div className="bg-white rounded shadow-lg p-4 w-full max-w-2xl mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold mb-1">Style</label>
            <select value={style} onChange={(e) => setStyle(e.target.value)} className="w-full border rounded p-2">
              <option value="">Select style</option>
              <option value="mini dress">Mini Dress</option>
              <option value="ball gown">Ball Gown</option>
              <option value="cocktail dress">Cocktail Dress</option>
              <option value="slip dress">Slip Dress</option>
              <option value="haute couture gown">Haute Couture Gown</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1">Fabric</label>
            <select value={fabric} onChange={(e) => setFabric(e.target.value)} className="w-full border rounded p-2">
              <option value="">Select fabric</option>
              <option value="silk">Silk</option>
              <option value="velvet">Velvet</option>
              <option value="leather">Leather</option>
              <option value="cotton">Cotton</option>
              <option value="satin">Satin</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1">Color</label>
            <select value={color} onChange={(e) => setColor(e.target.value)} className="w-full border rounded p-2">
              <option value="">Select color</option>
              <option value="black">Black</option>
              <option value="white">White</option>
              <option value="red">Red</option>
              <option value="blue">Blue</option>
              <option value="gold">Gold</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1">Neckline</label>
            <select value={neckline} onChange={(e) => setNeckline(e.target.value)} className="w-full border rounded p-2">
              <option value="">Select neckline</option>
              <option value="V-neck">V-neck</option>
              <option value="plunging">Plunging</option>
              <option value="halter">Halter</option>
              <option value="scoop">Scoop</option>
              <option value="off-the-shoulder">Off the Shoulder</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1">Sleeves</label>
            <select value={sleeves} onChange={(e) => setSleeves(e.target.value)} className="w-full border rounded p-2">
              <option value="">Select sleeves</option>
              <option value="no">No sleeves</option>
              <option value="short">Short</option>
              <option value="long">Long</option>
              <option value="puff">Puff sleeves</option>
              <option value="bell">Bell sleeves</option>
            </select>
          </div>
        </div>
      </div>

      <button onClick={handleGenerate} className="bg-black text-white px-4 py-2 rounded mb-6">Generate Outfit Prompt</button>

      {generatedPrompt && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-4 rounded shadow-lg max-w-2xl w-full">
          <h2 className="text-xl font-bold mb-2">Generated Prompt:</h2>
          <p className="text-gray-700">{generatedPrompt}</p>
          <p className="mt-2 text-sm text-gray-500">(Copy this into an AI image generator like Midjourney or DALL·E)</p>
        </motion.div>
      )}
    </div>
  );
}